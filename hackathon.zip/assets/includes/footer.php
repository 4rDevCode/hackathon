<!--<div class="footer-area">
  <p>© Copyright 2023. Todos los derechos reservados. <a href="https://utp.edu.pe/hackathon-utp-comercio"
            target="_blank">Hackathon</a>.</p>
</div>
-->